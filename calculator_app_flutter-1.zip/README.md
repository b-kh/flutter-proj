# ماشین حساب Flutter

یک ماشین حساب ساده و زیبا که با فریمورک Flutter ساخته شده است.

## ویژگی‌ها

✅ **عملیات ریاضی اصلی**: جمع، تفریق، ضرب، تقسیم  
✅ **پاک کردن**: دکمه AC برای پاک کردن کامل  
✅ **بازگشت**: دکمه ⌫ برای حذف آخرین رقم  
✅ **اعشار**: پشتیبانی از اعداد اعشاری  
✅ **طراحی زیبا**: رنگ‌بندی مشابه ماشین حساب iOS  
✅ **واکنشگرا**: سازگار با اندازه‌های مختلف صفحه  

## پیش نیازها

- Flutter SDK (نسخه 2.19.0 یا بالاتر)
- Android Studio یا VS Code
- یک دستگاه اندروید یا شبیه‌ساز

## نصب و راه‌اندازی

### 1. کلون کردن پروژه
```bash
git clone <repository-url>
cd calculator_app
```

### 2. نصب وابستگی‌ها
```bash
flutter pub get
```

### 3. اجرای اپلیکیشن
```bash
# اجرا در حالت توسعه
flutter run

# اجرا در حالت release
flutter run --release
```

### 4. ساخت فایل APK
```bash
flutter build apk --release
```

فایل APK در مسیر `build/app/outputs/flutter-apk/app-release.apk` قرار خواهد گرفت.

## ساختار پروژه

```
calculator_app/
├── lib/
│   └── main.dart          # کد اصلی اپلیکیشن
├── android/               # تنظیمات اندروید
├── ios/                  # تنظیمات iOS
├── test/                 # تست‌ها
├── web/                  # پشتیبانی وب
├── pubspec.yaml          # تنظیمات پروژه
└── README.md            # این فایل
```

## راهنمای استفاده

1. **اعداد**: روی اعداد ضربه بزنید تا در نمایشگر ظاهر شوند
2. **عملیات**: از دکمه‌های +، -، ×، ÷ برای انجام عملیات استفاده کنید
3. **نتیجه**: دکمه = را برای محاسبه نتیجه فشار دهید
4. **پاک کردن**: دکمه AC برای پاک کردن کامل
5. **حذف**: دکمه ⌫ برای حذف آخرین رقم

## تنظیمات اضافی

### تغییر نام اپلیکیشن
فایل `android/app/src/main/AndroidManifest.xml` را ویرایش کنید:
```xml
<application
    android:label="نام جدید اپلیکیشن"
    ...>
```

### تغییر آیکن
آیکن جدید را در مسیر `android/app/src/main/res/mipmap-*/` قرار دهید.

## مسائل رایج

### خطای "Flutter SDK not found"
مطمئن شوید که Flutter در PATH شما قرار دارد و دستور `flutter doctor` را اجرا کنید.

### خطای "Gradle build failed"
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
```

## مشارکت

1. Fork کنید
2. شاخه جدید بسازید (`git checkout -b feature/amazing-feature`)
3. تغییرات خود را commit کنید (`git commit -m 'Add amazing feature'`)
4. Push کنید (`git push origin feature/amazing-feature`)
5. Pull Request باز کنید

## لایسنس

این پروژه تحت لایسنس MIT منتشر شده است.

## پشتیبانی

اگر مشکلی داشتید، لطفاً یک Issue ایجاد کنید.

---

**نوت**: این اپلیکیشن برای آموزش و استفاده شخصی ساخته شده است.
