import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ماشین حساب',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Vazir', // برای فونت فارسی
      ),
      home: CalculatorScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _output = "0";
  String _displayText = "0";
  double _num1 = 0;
  double _num2 = 0;
  String _operator = "";
  bool _shouldResetDisplay = false;

  void _buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == "AC") {
        _output = "0";
        _displayText = "0";
        _num1 = 0;
        _num2 = 0;
        _operator = "";
        _shouldResetDisplay = false;
      } else if (buttonText == "⌫") {
        if (_displayText.length > 1) {
          _displayText = _displayText.substring(0, _displayText.length - 1);
          _output = _displayText;
        } else {
          _displayText = "0";
          _output = "0";
        }
      } else if (buttonText == "+" || buttonText == "-" || 
                 buttonText == "×" || buttonText == "÷") {
        if (_operator.isNotEmpty && !_shouldResetDisplay) {
          _calculate();
        }
        _num1 = double.parse(_output);
        _operator = buttonText;
        _shouldResetDisplay = true;
      } else if (buttonText == "=") {
        _calculate();
        _operator = "";
        _shouldResetDisplay = true;
      } else if (buttonText == ".") {
        if (!_displayText.contains(".")) {
          _displayText = _displayText + ".";
          _output = _displayText;
        }
      } else {
        // عدد وارد شده
        if (_shouldResetDisplay) {
          _displayText = buttonText;
          _shouldResetDisplay = false;
        } else {
          _displayText = (_displayText == "0") ? buttonText : _displayText + buttonText;
        }
        _output = _displayText;
      }
    });
  }

  void _calculate() {
    if (_operator.isNotEmpty) {
      _num2 = double.parse(_output);
      double result = 0;

      switch (_operator) {
        case "+":
          result = _num1 + _num2;
          break;
        case "-":
          result = _num1 - _num2;
          break;
        case "×":
          result = _num1 * _num2;
          break;
        case "÷":
          if (_num2 != 0) {
            result = _num1 / _num2;
          } else {
            _output = "خطا";
            _displayText = "خطا";
            return;
          }
          break;
      }

      // نمایش نتیجه
      if (result == result.roundToDouble()) {
        _output = result.round().toString();
      } else {
        _output = result.toStringAsFixed(8).replaceAll(RegExp(r'0*$'), '').replaceAll(RegExp(r'\.$'), '');
      }
      _displayText = _output;
      _num1 = result;
    }
  }

  Widget _buildButton(String buttonText, {Color? color, Color? textColor}) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(4),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: color ?? Colors.grey[200],
            foregroundColor: textColor ?? Colors.black,
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: EdgeInsets.all(20),
          ),
          onPressed: () => _buttonPressed(buttonText),
          child: Text(
            buttonText,
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('ماشین حساب', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
        elevation: 0,
      ),
      body: Column(
        children: [
          // نمایشگر
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(vertical: 40, horizontal: 20),
            child: Text(
              _output,
              style: TextStyle(
                fontSize: 48,
                color: Colors.white,
                fontWeight: FontWeight.w300,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),

          Expanded(
            child: Container(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  // ردیف اول
                  Expanded(
                    child: Row(
                      children: [
                        _buildButton("AC", color: Colors.grey[400]),
                        _buildButton("⌫", color: Colors.grey[400]),
                        _buildButton("", color: Colors.transparent),
                        _buildButton("÷", color: Colors.orange, textColor: Colors.white),
                      ],
                    ),
                  ),

                  // ردیف دوم
                  Expanded(
                    child: Row(
                      children: [
                        _buildButton("7"),
                        _buildButton("8"),
                        _buildButton("9"),
                        _buildButton("×", color: Colors.orange, textColor: Colors.white),
                      ],
                    ),
                  ),

                  // ردیف سوم
                  Expanded(
                    child: Row(
                      children: [
                        _buildButton("4"),
                        _buildButton("5"),
                        _buildButton("6"),
                        _buildButton("-", color: Colors.orange, textColor: Colors.white),
                      ],
                    ),
                  ),

                  // ردیف چهارم
                  Expanded(
                    child: Row(
                      children: [
                        _buildButton("1"),
                        _buildButton("2"),
                        _buildButton("3"),
                        _buildButton("+", color: Colors.orange, textColor: Colors.white),
                      ],
                    ),
                  ),

                  // ردیف پنجم
                  Expanded(
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Container(
                            margin: EdgeInsets.all(4),
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.grey[200],
                                foregroundColor: Colors.black,
                                elevation: 2,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                padding: EdgeInsets.all(20),
                              ),
                              onPressed: () => _buttonPressed("0"),
                              child: Text(
                                "0",
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        _buildButton("."),
                        _buildButton("=", color: Colors.orange, textColor: Colors.white),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
